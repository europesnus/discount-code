  <footer class="site-footer" role="contentinfo">
    <div class="container">
      <div class="affiliate-disclaimer-box">
        <strong>Commercial Disclosure:</strong> We provide independent verified discount codes and product reviews for Europesnus. We may receive affiliate commission on qualifying purchases. Nicotine is an addictive substance. 18+ only.
      </div>
      <div class="footer-top-grid">
        <div class="footer-col">
          <h5>Europesnus</h5>
          <p>
            Europesnus is a leading European online retailer specializing in 100% tobacco-free nicotine pouches and energy pouches. Offering premium brands like VELO, Killa, Pablo, and Iceberg with fast, tracked 2–5 day delivery across Europe and 541 verified customer reviews.
          </p>
        </div>
        <div class="footer-col">
          <h5>Coupon Guides</h5>
          <ul class="footer-links">
            <li><a href="<?php echo esc_url(home_url('/en/europesnus-discount-code/')); ?>">Europesnus Discount Code</a></li>
            <li><a href="<?php echo esc_url(home_url('/fi/europesnus-alennuskoodi/')); ?>">Europesnus Alennuskoodi (FI)</a></li>
            <li><a href="<?php echo esc_url(home_url('/de/europesnus-rabattkoder/')); ?>">Europesnus Rabattkoder (DE)</a></li>
            <li><a href="<?php echo esc_url(home_url('/se/europesnus-rabattkod/')); ?>">Europesnus Rabattkod (SE)</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h5>Review Highlights</h5>
          <ul class="footer-links">
            <li><a href="<?php echo esc_url(home_url('/#brand-review')); ?>">Brand Review</a></li>
            <li><a href="<?php echo esc_url(home_url('/#reviews-541')); ?>">541 Customer Reviews</a></li>
            <li><a href="<?php echo esc_url(home_url('/#shipping-guide')); ?>">EU Shipping Speeds</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h5>Legal &amp; Info</h5>
          <ul class="footer-links">
            <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
            <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About</a></li>
            <li><a href="<?php echo esc_url(home_url('/terms/')); ?>">Terms And Condition</a></li>
            <li><a href="<?php echo esc_url(home_url('/privacy/')); ?>">Privacy Policy</a></li>
            <li><a href="<?php echo esc_url(home_url('/disclaimer/')); ?>">Disclaimer</a></li>
            <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> Europesnus (europesnus.online). All rights reserved.</p>
        <p>18+ Adult Use Only</p>
      </div>
    </div>
  </footer>

  <!-- Modal -->
  <div class="modal-overlay" id="coupon-modal-overlay" role="dialog" aria-modal="true">
    <div class="coupon-modal-window">
      <button class="modal-close-btn" id="modal-close-btn">&times;</button>
      <span class="modal-header-badge">✓ Verified Working Code</span>
      <h3 class="modal-title" id="modal-coupon-title">55% Off Your Entire Order</h3>
      <p class="modal-desc" id="modal-coupon-desc">Copy this promo code and paste it into the checkout page at Europesnus.com.</p>
      <div class="code-copy-card">
        <span class="modal-code-string" id="modal-code-text">SNUSDEAL40</span>
        <button class="modal-copy-btn" id="modal-copy-action-btn">Copy Code</button>
      </div>
      <a href="https://europesnus.com/?ref=lrtwknyx" target="_blank" rel="noopener noreferrer" class="modal-redirect-btn" id="modal-redirect-link">
        <span>Go to Europesnus Store</span>
        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
      </a>
    </div>
  </div>

  <div class="toast-container" id="toast-container"></div>

  <?php wp_footer(); ?>
</body>
</html>
