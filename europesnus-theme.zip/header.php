<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  
  <!-- Favicon & Icons -->
  <link rel="icon" type="image/png" href="https://europesnus.online/wp-content/uploads/2026/09/europesnus_logo.png">
  <link rel="apple-touch-icon" href="https://europesnus.online/wp-content/uploads/2026/09/europesnus_logo.png">

  <!-- Hreflang Tags -->
  <link rel="alternate" hreflang="x-default" href="https://europesnus.online/">
  <link rel="alternate" hreflang="en" href="https://europesnus.online/en/europesnus-discount-code/">
  <link rel="alternate" hreflang="fi" href="https://europesnus.online/fi/europesnus-alennuskoodi/">
  <link rel="alternate" hreflang="de" href="https://europesnus.online/de/europesnus-rabattkoder/">
  <link rel="alternate" hreflang="sv" href="https://europesnus.online/se/europesnus-rabattkod/">
  <link rel="alternate" hreflang="nl" href="https://europesnus.online/nl/europesnus-kortingscode/">
  <link rel="alternate" hreflang="da" href="https://europesnus.online/dk/europesnus-rabatkode/">
  <link rel="alternate" hreflang="it" href="https://europesnus.online/it/europesnus-codice-sconto/">
  <link rel="alternate" hreflang="lv" href="https://europesnus.online/lv/europesnus-atlaizu-kods/">

  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

  <div class="header-top-bar">
    <div class="container">
      <div class="header-top-inner">
        <div class="top-trust-highlights">
          <span class="top-trust-item">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            <strong>541 Verified 5-Star Reviews</strong> (4.95/5.0)
          </span>
          <span class="top-trust-item">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            Fast 2–5 Day Tracked EU Shipping
          </span>
        </div>

        <div class="lang-selector-wrap">
          <span class="lang-selector-label">Language:</span>
          <ul class="lang-nav-pills">
            <li><a href="<?php echo esc_url(home_url('/en/europesnus-discount-code/')); ?>">EN</a></li>
            <li><a href="<?php echo esc_url(home_url('/fi/europesnus-alennuskoodi/')); ?>">FI</a></li>
            <li><a href="<?php echo esc_url(home_url('/de/europesnus-rabattkoder/')); ?>">DE</a></li>
            <li><a href="<?php echo esc_url(home_url('/se/europesnus-rabattkod/')); ?>">SE</a></li>
            <li><a href="<?php echo esc_url(home_url('/lv/europesnus-atlaizu-kods/')); ?>">LV</a></li>
            <li><a href="<?php echo esc_url(home_url('/it/europesnus-codice-sconto/')); ?>">IT</a></li>
            <li><a href="<?php echo esc_url(home_url('/nl/europesnus-kortingscode/')); ?>">NL</a></li>
            <li><a href="<?php echo esc_url(home_url('/dk/europesnus-rabatkode/')); ?>">DK</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <header class="site-header" role="banner">
    <div class="container">
      <div class="header-inner">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
          <img src="https://europesnus.online/wp-content/uploads/2026/09/europesnus_logo.png" alt="Europesnus Logo" class="logo-img" width="48" height="48">
          <div class="logo-text">
            <span class="brand-name">Europesnus</span>
            <span class="brand-tagline">Discount Code</span>
          </div>
        </a>

        <nav class="main-nav" role="navigation">
          <ul class="nav-links">
            <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
            <li><a href="<?php echo esc_url(home_url('/en/europesnus-discount-code/')); ?>">Discount Codes</a></li>
            <li><a href="<?php echo esc_url(home_url('/#brand-review')); ?>">Brand Review</a></li>
            <li><a href="<?php echo esc_url(home_url('/#reviews-541')); ?>">541 Reviews</a></li>
            <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About</a></li>
            <li><a href="<?php echo esc_url(home_url('/terms/')); ?>">Terms</a></li>
            <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a></li>
          </ul>
        </nav>

        <a href="https://europesnus.com/?ref=lrtwknyx" target="_blank" rel="nofollow noopener" class="header-cta">
          <span>Visit Europesnus</span>
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
        </a>
      </div>
    </div>
  </header>
