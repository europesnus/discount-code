<?php
/**
 * Europesnus Theme Functions
 */

function europesnus_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
}
add_action('after_setup_theme', 'europesnus_theme_setup');

function europesnus_theme_scripts() {
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Outfit:wght@600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap', array(), null);
    wp_enqueue_style('europesnus-style', get_stylesheet_uri(), array(), '2.3.0');
    wp_enqueue_script('europesnus-app', get_template_directory_uri() . '/app.js', array(), '2.3.0', true);
}
add_action('wp_enqueue_scripts', 'europesnus_theme_scripts');

// Clean, High-CTR SERP Document Titles
add_filter('document_title_parts', function($parts) {
    if (is_front_page()) {
        $parts['title'] = 'Europesnus Review: Legitimacy, Products, Shipping & 541 Reviews';
    }
    unset($parts['site']);
    unset($parts['tagline']);
    return $parts;
}, 99);

// Custom Meta Tags & Schema
function europesnus_custom_head_seo() {
    $logo_url = 'https://europesnus.online/wp-content/uploads/2026/09/europesnus_logo.png';
    $current_url = home_url(add_query_arg(array(), $GLOBALS['wp']->request));
    if (!str_ends_with($current_url, '/')) {
        $current_url .= '/';
    }

    if (is_front_page()) {
        $meta_desc = 'Honest Europesnus review: 541 customer ratings (4.95/5), factory-fresh VELO & Killa pouches, fast tracked 2–5 day EU delivery, and verified 55% off discount codes.';
        $canonical = home_url('/');
    } else {
        $post = get_queried_object();
        $slug = is_object($post) && isset($post->post_name) ? $post->post_name : '';
        
        $meta_descriptions = [
            'europesnus-discount-code' => 'Get 16 verified Europesnus discount codes & promo vouchers for 2026. Save up to 55% on VELO, Killa, Pablo & Iceberg with fast tracked European delivery.',
            'europesnus-alennuskoodi' => 'Säästä jopa 55% voimassa olevilla Europesnus alennuskoodeilla. Lue suomalaisten aitoja kokemuksia, toimitusajat Suomeen ja parhaat nikotiinipussitarjoukset.',
            'europesnus-rabattkoder' => 'Aktuelle Europesnus Rabattkodes & Gutscheine für Deutschland & Österreich. Sparen Sie bis zu 55% auf VELO, Killa & Iceberg mit geprüftem 2–4 Tage Versand.',
            'europesnus-rabattkod' => 'Hitta 16 verifierade Europesnus rabattkoder för 2026. Spara upp till 55% på tobaksfria nikotinpåsar som VELO, Killa & Pablo med snabb 2–4 dagars leverans.',
            'europesnus-kortingscode' => 'Bespaar tot 55% met 16 werkende Europesnus kortingscodes voor Nederland & België. Ontdek volumekortingen, ervaringen en snelle 2–3 dagen levering.',
            'europesnus-rabatkode' => 'Find 16 verificerede Europesnus rabatkoder for 2026. Spar op til 55% på nikotinposer med hurtig 1–3 dages levering i Danmark og automatiske mængderabatter.',
            'europesnus-codice-sconto' => 'Tutti i codici sconto Europesnus verificati per il 2026. Risparmia fino al 55% su bustine di nicotina senza tabacco (VELO, Killa) con spedizione tracciata UE.',
            'europesnus-atlaizu-kods' => 'Pārbaudīti Europesnus atlaižu kodi un kuponi 2026. gadam. Ietaupiet līdz 55% uz nikotīna spilventiņiem ar ātru 3–5 dienu piegādi uz Latviju.',
            'about' => 'Learn about our editorial mission, coupon verification standards, and authentic review methodology for Europesnus consumers.',
            'terms' => 'Terms and conditions for utilizing Europesnus discount codes, guides, and promotional information.',
            'privacy' => 'Privacy Policy for Europesnus detailing data protection and GDPR compliance.',
            'disclaimer' => 'Legal disclaimer, affiliate transparency disclosure, and health notice for Europesnus.',
            'contact' => 'Contact the editorial team at Europesnus to submit coupon updates, report broken promo codes, or request information.'
        ];

        $meta_desc = isset($meta_descriptions[$slug]) ? $meta_descriptions[$slug] : 'Verified Europesnus reviews, discounts, and buyer guides.';
        $canonical = $current_url;
    }

    echo '<meta name="description" content="' . esc_attr($meta_desc) . '">' . "\n";
    echo '<link rel="canonical" href="' . esc_url($canonical) . '">' . "\n";
    echo '<meta property="og:site_name" content="Europesnus">' . "\n";
    echo '<meta property="og:image" content="' . esc_url($logo_url) . '">' . "\n";
}
add_action('wp_head', 'europesnus_custom_head_seo', 1);
