<?php
get_header();
?>

<main id="main-content" style="padding: 48px 0;">
  <div class="container" style="max-width: 860px;">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <h1 style="font-family:var(--font-display); font-size:2.2rem; font-weight:800; margin-bottom:20px;"><?php the_title(); ?></h1>
                <div style="color:var(--text-secondary); line-height:1.7;">
                    <?php the_content(); ?>
                </div>
            </article>
            <?php
        endwhile;
    endif;
    ?>
  </div>
</main>

<?php
get_footer();
